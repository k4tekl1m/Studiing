$(document).ready(function(){
    $("#leftSidebar").mouseenter(function(){

        $(this).animate({width: "300px"})
        
    })
    $("#leftSidebar").mouseleave(function(){
        $(this).animate({width: "30px"})
    })
    $.ajax({
        url:'https://dummyjson.com/recipes',
        method: 'get',
        dataType: 'json',
        succes:function(data){
            let recipesArray = data.recipesArray
            recipesArray.forEach(recipe =>{
                console.log(recipe)
                $("#cardGrid").append(`
                <div class="col-4">
                    <div class="card mt-3">
                        <img src="${recipe.image}" alt="" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">${recipe.name}</h5>
                            <p class="card-text"></p>
                            <a href="#" class="btn btn-primary">see more...</a>
                        </div>
                    </div>
                </div>
                `)
            });
        }

    });









})





url:



{/*  */}