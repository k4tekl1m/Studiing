// a = 5;
// нельзя создавать переменную начиная с цифры и всякими знаками
// первое слово всегда с маленькой остальные слитно и с большой
// dayOfWeek
// day_of_week

// dayOfWeek = 3

// язык регистрозависимый - разный регистр разные элементы

number1 = 5
number2 = 10
console.log("Привет")

//типы данных
//Number 
// number3 = number1 + number2
// number3 = number1 - number2
// number3 = number1 * number2
// number3 = number1 ** number2 - степень
// number3 = number1 ** -number2 - степень отрицательная (инверсия)
// number3 = number1 / number2
// number3 = number1 % number2
// number1 = number1 + 1
// number1 = 1
// number1++ увелич на единицу
// number1-- уменьш на единицу
// console.log(number3)
// number1<number2
// number1>number2
// number1==number2 -сравнение
// number1!=number2 - проверка
// number1=>number2
// number1<=number2
// console.log(number1)

// Boolean
// true false

// true = 1
// false = 0

// temp = (number1==number2)
// console.log(temp)
// console.log(1==true)

// String
// myString = "hello"
// console.log(myString)

// asd = "hello"
// console.log(asd + number1)
// console.log("5"+"5")
// console.log("5"-"5")
// console.log(asd - number1)
// console.log(Infinity)
// console.log(asd + " " + asd)
// console.log(asd [1])

// null - пустота результат возврата

// Symbol
// ╚
// Object

number3 = 5*(5+7)/2

console.log (typeof(number1))

//alert ("Привет")
// answer1 = prompt("Сколько вам лет?")
// answer1 = +prompt("Сколько вам лет?")
// console.log (answer1)
// console.log (number3)
// console.log (typeof(answer1))
//данные о максимальной скорости передачи данных
Umax = 2+6/(1+2)
console.log (Umax)

// Условия и условные операторы 
if(1==2){
    //действие1
    alert("да")
}
age = 15
height = 190
uname = "Vadim"
//если возраст больше 18 и рост больше 180
// if(age>18){
//     if(height>180){
//         alert("вам можно")
//     }    
// }
// if(age>18 && height>180){
//         alert("вам можно") 
// }
// if(age>18 && height>180 && uname!="Никита"){
//     alert("вам можно") 
// }
// if(age>18 || height>180 && uname!="Никита"){
//     alert("вам можно") 
// }
// true && true =>true
// true && false =>false
// false && false =>false

// true || true =>true
// true || false =>false
// false || false =>false

// if(age>18){
//     alert("Вам можно")
// }
// else{
//     alert("Вам нельзя")
// }
// else{
//     alert("Вам нельзя")
// }
// if(height>170){
//     alert("Ты высокий")
// }
// else if(height>170){
//     alert("Ты высокий")
// }


// age>18 ? alert("Вам можно") : alert("Вам нельзя")

// permission = age>18 ? "Вам можно" : "Вам нельзя"
// alert(permission)


// dayOfWeek = "мЫЯ"

// switch(dayOfWeek){
//     case "Понедельник":
//         alert("Хорошей рабочей недели")
//         break
//     case "Вторник":
//         alert("Держись")
//         break
//     case "Среда":
//         alert("фу, среда")
//         break
//     default:
//         alert("Вы что-то не то написали")
// }


// x = 10
// if(x>=0 & x<=9){
//     alert("true")
// }
// else{
//     alert("false")
// }


// U = 8
// if(U%2==0){
//     alert("Четное")
// }else{
//     alert("Нечетное")
// }

// alert(typeof(1+true))
// alert(typeof('1'+2))
// alert(typeof('1'+false))

x = 7
y = 5
if(x>y){
    alert("x>y")
}
if(x<y){
    alert("x<y")

}
if(x==y){
    alert("x=y")
}

